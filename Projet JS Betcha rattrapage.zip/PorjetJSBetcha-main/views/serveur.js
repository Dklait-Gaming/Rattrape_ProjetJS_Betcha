document.addEventListener('DOMContentLoaded', () => {

    document.body.style.backgroundImage="url('violet clair.jpg')";

});



 
